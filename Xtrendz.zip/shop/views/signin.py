from django.views import View
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from shop.models.customer import Customer
from django.views import View


class Signin(View):
    def get(self, request):
        return render(request, 'signin.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('pass1')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                return redirect('homepage')
            else:
                error_message = "credential's invalid!!"
        else:
            error_message = "credential's invalid!!"
        print(email, password)
        return render(request, 'signin.html', {'error': error_message})

def logout(request):
    request.session.clear()
    return redirect('homepage')



